import * as React from 'react';
import { Icon } from './icon/Icon';
import styled from 'styled-components';

export const Logo=()=>{
    return(
        <StyledLogo>
          
           
          
             <Icon iconId={'logo'}/>
 
            
            

       
         
         </StyledLogo>
         
        

    )
}

  const StyledLogo=styled.div`
  display: flex;

 

    
  `


   
  

   

    
  
