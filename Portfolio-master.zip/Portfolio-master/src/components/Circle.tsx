import * as React from 'react';
import styled from 'styled-components';
export const Circle=()=>{
    return(
        
           

<CicleExperience>
    </CicleExperience>




    )
}
const CicleExperience=styled.div`
    width: 25px;
    height: 25px;
   

    background: #fffefe;
    -moz-border-radius:20px;
    -webkit-border-radius:40px;
    border-radius: 50px;
   


`



