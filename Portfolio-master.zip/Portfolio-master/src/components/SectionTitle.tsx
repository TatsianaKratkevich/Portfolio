import styled from "styled-components";
 export const SectionTitle = styled.h2`
 color:white;
 font-family: Poppins;
font-size: 46px;
font-weight: 600;
line-height: normal;
margin-bottom: 70px;
 
 `